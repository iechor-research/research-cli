/**
 * @license
 * Copyright 2025 iEchor LLC
 * SPDX-License-Identifier: Apache-2.0
 */

export { AcademicWritingAssistant } from './academic-writing-assistant.js'; 